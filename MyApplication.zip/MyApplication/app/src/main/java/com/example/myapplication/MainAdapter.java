package com.example.myapplication;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import java.util.List;

public class MainAdapter extends RecyclerView.Adapter<MainAdapter.Holder> {

    private List<Question> list;

    public MainAdapter(List<Question> list) {
        this.list = list;
    }

    @NonNull
    @Override
    public Holder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        LayoutInflater inflater = LayoutInflater.from(viewGroup.getContext());
        View view = inflater.inflate(R.layout.item_main, viewGroup, false);

        return new Holder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull Holder holder, int i) {
        Question question = list.get(i);

        TextView text = holder.questionText;
        text.setText(question.getText());

        RadioGroup group = holder.answerGroup;
        for (int c = 0; c < 4; c++) {
            RadioButton button = (RadioButton) group.getChildAt(c);
            button.setText(question.getAnswer(c).getText());
        }
    }

    @Override
    public int getItemCount() {
        return list == null ? 0 : list.size();
    }

    public static class Holder extends RecyclerView.ViewHolder {

        private TextView questionText;
        private RadioGroup answerGroup;

        public Holder(@NonNull View itemView) {
            super(itemView);
            questionText = itemView.findViewById(R.id.textView);
            answerGroup = itemView.findViewById(R.id.radioGroup);
        }
    }
}
