package com.example.myapplication;

import java.util.Objects;

public class Answer {

    private boolean isCorrect;
    private String text;

    public Answer(boolean isCorrect, String text) {
        Objects.requireNonNull(text);

        this.isCorrect = isCorrect;
        this.text = text;
    }

    public boolean isCorrect() {
        return isCorrect;
    }

    public String getText() {
        return text;
    }
}
