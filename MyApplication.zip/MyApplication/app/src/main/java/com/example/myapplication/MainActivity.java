package com.example.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private LinearLayoutManager layoutManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        layoutManager = new LinearLayoutManager(this);
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(layoutManager);

        recyclerView.setAdapter(new MainAdapter(getRandomQuestions( 10, 0)));
    }

    private List<Question> getRandomQuestions(int count, final int minKarma) {
        List<Question> filtered = getQuestions().stream()
                .filter(q -> q.getKarma() >= minKarma)
                .collect(Collectors.toList());

        if (filtered.size() > count) {
            Random random = new Random();

            while (filtered.size() > count) {
                Question q = filtered.get(random.nextInt(filtered.size()));
                filtered.remove(q);
            }
        }
        return filtered;
    }

    private List<Question> getQuestions() {
        Question.Builder builder = new Question.Builder();

        List<Question> list = new ArrayList<>();
        for (int i = 0; i < 50; i++) {
            list.add(builder.build()
                    .question("Who is #" + i, 0)
                    .correct("It is me")
                    .wrong("Not me", "other", "what")
                    .create()
            );
        }
        return list;
    }
}
