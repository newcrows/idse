package com.example.myapplication;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;

public class Question {

    private String text;
    private int karma;
    private List<Answer> answers;

    public static Builder builder() {
        return new Builder();
    }

    public Question(String text, int karma, Answer... answers) {
        Objects.requireNonNull(text);
        Objects.requireNonNull(answers);
        if (answers.length != 4) {
            throw new IllegalArgumentException("Must have exactly 4 answers");
        }

        this.text = text;
        this.karma = karma;
        this.answers = Arrays.asList(answers);
    }

    public String getText() {
        return text;
    }

    public int getKarma() {
        return karma;
    }

    public Answer getAnswer(int i) {
        return answers.get(i);
    }

    public static class Builder {

        private String text;
        private int karma;
        private Answer[] answers;
        private int i;

        public Builder build() {
            answers = new Answer[4];
            i = 0;
            return this;
        }

        public Builder question(String text, int karma) {
            this.text = text;
            this.karma = karma;
            return this;
        }

        public Builder correct(String text) {
            answers[0] = new Answer(true, text);
            return this;
        }

        public Builder wrong(String... texts) {
            for (int i = 1; i < 4; i++) {
                answers[i] = new Answer(false, texts[i-1]);
            }
            return this;
        }

        public Question create() {
            return new Question(text, karma, answers);
        }
    }
}
